// 全局命名空间
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  const GRID_SIZE = 40;
  let idCounter = 0;
  const idMap = new WeakMap(); // 稳定ID映射

  /**
   * 为元素生成稳定ID
   */
  function getStableId(el) {
    if (idMap.has(el)) return idMap.get(el);
    if (el.id) {
      idMap.set(el, el.id);
      return el.id;
    }
    const id = `el_${el.tagName.toLowerCase()}_${++idCounter}`;
    idMap.set(el, id);
    return id;
  }

  /**
   * 扫描单个元素（不是整个页面）
   */
  function scanElement(el) {
    if (!el || !el.getBoundingClientRect) return null;
    
    const rect = el.getBoundingClientRect();
    
    // 过滤太小/不可见的元素
    if (rect.width < 3 || rect.height < 3) return null;
    
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) return null;
    
    // 过滤纯装饰/无意义元素
    const tag = el.tagName.toLowerCase();
    const skipTags = new Set(['br','hr','script','style','link','meta','noscript','svg','path','g','defs','use']);
    if (skipTags.has(tag)) return null;
    
    const id = getStableId(el);
    
    return {
      id,
      tag,
      text: (el.textContent || '').trim().substring(0, 100),
      bounds: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        w: Math.round(rect.width),
        h: Math.round(rect.height)
      },
      grid: {
        gx: Math.floor(rect.x / GRID_SIZE),
        gy: Math.floor(rect.y / GRID_SIZE),
        gw: Math.ceil(rect.width / GRID_SIZE),
        gh: Math.ceil(rect.height / GRID_SIZE)
      },
      interactive: isInteractive(el, tag, style),
      semantic: inferSemanticRole(el, tag),
      attributes: {
        role: el.getAttribute('role'),
        ariaLabel: el.getAttribute('aria-label'),
        className: el.className || '',
        href: el.getAttribute('href'),
        type: el.getAttribute('type'),
        placeholder: el.getAttribute('placeholder')
      },
      depth: getDepth(el),
      _el: el // 保留 DOM 引用（内部使用，不暴露给 Agent）
    };
  }

  function isInteractive(el, tag, style) {
    const interactiveTags = new Set(['a','button','input','select','textarea','option','details','summary']);
    if (interactiveTags.has(tag)) return true;
    if (el.getAttribute('onclick') || el.getAttribute('tabindex')) return true;
    if (style.cursor === 'pointer') return true;
    if (el.getAttribute('role') === 'button') return true;
    return false;
  }

  function inferSemanticRole(el, tag) {
    // 1. ARIA role
    const ariaRole = el.getAttribute('role');
    if (ariaRole) return ariaRole;
    
    // 2. 语义化标签
    const tagRoles = {
      nav: 'navigation', header: 'banner', footer: 'contentinfo',
      main: 'main', aside: 'complementary', article: 'article',
      section: 'region', form: 'form', button: 'button',
      a: 'link', input: 'input', select: 'listbox',
      textarea: 'textbox', h1: 'heading', h2: 'heading',
      h3: 'heading', h4: 'heading', h5: 'heading', h6: 'heading',
      img: 'img', video: 'video', audio: 'audio',
      table: 'table', ul: 'list', ol: 'list', li: 'listitem',
      dialog: 'dialog', menu: 'menu'
    };
    if (tagRoles[tag]) return tagRoles[tag];
    
    // 3. class/id 启发式
    const cls = (el.className || '').toLowerCase() + ' ' + (el.id || '').toLowerCase();
    const heuristics = [
      [/nav|menu/, 'navigation'], [/btn|button/, 'button'],
      [/card/, 'card'], [/hero|banner/, 'banner'],
      [/sidebar/, 'complementary'], [/modal|dialog|popup/, 'dialog'],
      [/tab/, 'tab'], [/dropdown/, 'listbox'],
      [/tooltip/, 'tooltip'], [/carousel|slider/, 'group'],
      [/cta/, 'cta'], [/footer/, 'contentinfo'],
      [/header/, 'banner']
    ];
    for (const [pattern, role] of heuristics) {
      if (pattern.test(cls)) return role;
    }
    
    return 'content';
  }

  function getDepth(el) {
    let depth = 0;
    let current = el;
    while (current.parentElement) { depth++; current = current.parentElement; }
    return depth;
  }

  // 全量扫描（初始化用）
  function scanAll() {
    const elements = [];
    document.querySelectorAll('*').forEach(el => {
      const node = scanElement(el);
      if (node) elements.push(node);
    });
    return elements;
  }

  global.AgentRuntime.scanner = { scanElement, scanAll, getStableId, GRID_SIZE };
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  class OccupancyGrid {
    constructor(cellSize = 40) {
      this.cellSize = cellSize;
      this.grid = [];
      this.cols = 0;
      this.rows = 0;
    }

    /**
     * 全量重建（初始化用）
     */
    rebuild(elements) {
      this.cols = Math.ceil(window.innerWidth / this.cellSize);
      this.rows = Math.ceil(document.body.scrollHeight / this.cellSize);
      
      // 初始化空网格
      this.grid = Array.from({ length: this.rows }, () =>
        Array.from({ length: this.cols }, () => ({ occupied: false, ids: [] }))
      );
      
      // 填充
      elements.forEach(el => this.paintElement(el));
    }

    /**
     * 增量更新：只更新变化的元素
     */
    incrementalUpdate(changedElements) {
      // 先清除旧位置
      changedElements.forEach(el => this.clearElement(el.id));
      // 再画新位置
      changedElements.forEach(el => this.paintElement(el));
    }

    /**
     * 画一个元素到网格
     */
    paintElement(el) {
      const { gx, gy, gw, gh } = el.grid;
      for (let y = gy; y < gy + gh && y < this.rows; y++) {
        for (let x = gx; x < gx + gw && x < this.cols; x++) {
          if (this.grid[y] && this.grid[y][x]) {
            this.grid[y][x].occupied = true;
            if (!this.grid[y][x].ids.includes(el.id)) {
              this.grid[y][x].ids.push(el.id);
            }
          }
        }
      }
    }

    /**
     * 清除一个元素在网格中的占位
     */
    clearElement(id) {
      for (let y = 0; y < this.rows; y++) {
        for (let x = 0; x < this.cols; x++) {
          if (this.grid[y] && this.grid[y][x]) {
            const idx = this.grid[y][x].ids.indexOf(id);
            if (idx !== -1) {
              this.grid[y][x].ids.splice(idx, 1);
              this.grid[y][x].occupied = this.grid[y][x].ids.length > 0;
            }
          }
        }
      }
    }

    /**
     * 查询某个网格格子的状态
     */
    getCell(gx, gy) {
      return this.grid?.[gy]?.[gx] || null;
    }

    /**
     * 检测重叠
     */
    detectOverlaps(elements) {
      const overlaps = [];
      for (let i = 0; i < elements.length; i++) {
        for (let j = i + 1; j < elements.length; j++) {
          const a = elements[i].grid, b = elements[j].grid;
          if (a.gx < b.gx + b.gw && a.gx + a.gw > b.gx &&
              a.gy < b.gy + b.gh && a.gy + a.gh > b.gy) {
            overlaps.push([elements[i].id, elements[j].id]);
          }
        }
      }
      return overlaps;
    }
  }

  global.AgentRuntime.OccupancyGrid = OccupancyGrid;
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  /**
   * 构建拓扑关系
   */
  function buildTopology(elements) {
    const adjacency = new Map(); // id → {top, bottom, left, right}
    const navigationPath = [];
    
    // 按y坐标排序构建纵向浏览路径
    const sorted = [...elements].sort((a, b) => a.bounds.y - b.bounds.y);
    
    let prevRow = null;
    sorted.forEach(el => {
      const row = Math.floor(el.bounds.y / 100); // 100px为一行
      if (row !== prevRow) {
        navigationPath.push({ row, elements: [el.id] });
        prevRow = row;
      } else {
        navigationPath[navigationPath.length - 1].elements.push(el.id);
      }
    });
    
    // 计算每个元素的邻近关系
    elements.forEach(el => {
      const neighbors = { top: [], bottom: [], left: [], right: [] };
      
      elements.forEach(other => {
        if (el.id === other.id) return;
        const dist = elementDistance(el, other);
        if (dist > 3) return; // 超过3格不算邻居
        
        // 判断方向
        const dx = other.bounds.x - el.bounds.x;
        const dy = other.bounds.y - el.bounds.y;
        
        if (Math.abs(dy) > Math.abs(dx)) {
          if (dy < 0) neighbors.top.push({ id: other.id, dist });
          else neighbors.bottom.push({ id: other.id, dist });
        } else {
          if (dx < 0) neighbors.left.push({ id: other.id, dist });
          else neighbors.right.push({ id: other.id, dist });
        }
      });
      
      // 每个方向只保留最近的
      Object.keys(neighbors).forEach(dir => {
        neighbors[dir].sort((a, b) => a.dist - b.dist);
        neighbors[dir] = neighbors[dir].slice(0, 3).map(n => n.id);
      });
      
      adjacency.set(el.id, neighbors);
    });
    
    return { adjacency, navigationPath };
  }

  function elementDistance(a, b) {
    const GRID_SIZE = 40;
    const ax = a.bounds.x + a.bounds.w / 2;
    const ay = a.bounds.y + a.bounds.h / 2;
    const bx = b.bounds.x + b.bounds.w / 2;
    const by = b.bounds.y + b.bounds.h / 2;
    return Math.sqrt(((ax - bx) / GRID_SIZE) ** 2 + ((ay - by) / GRID_SIZE) ** 2);
  }

  global.AgentRuntime.topology = { buildTopology, elementDistance };
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  /**
   * 构建语义索引
   */
  function buildSemanticIndex(elements) {
    const byRole = {};
    const byRegion = {};
    
    elements.forEach(el => {
      // 按角色分组
      if (!byRole[el.semantic]) byRole[el.semantic] = [];
      byRole[el.semantic].push(el.id);
      
      // 按区域分组（用 y 范围划分：header/body/footer）
      const region = getRegion(el);
      if (!byRegion[region]) byRegion[region] = [];
      byRegion[region].push(el.id);
    });
    
    return { byRole, byRegion };
  }

  function getRegion(el) {
    const viewportH = window.innerHeight;
    const y = el.bounds.y;
    if (y < viewportH * 0.15) return 'header';
    if (y > document.body.scrollHeight - viewportH * 0.15) return 'footer';
    return 'body';
  }

  /**
   * 计算注意力权重
   */
  function calculateAttentionWeights(elements) {
    const maxArea = Math.max(...elements.map(e => e.bounds.w * e.bounds.h), 1);
    
    elements.forEach(el => {
      const sizeScore = (el.bounds.w * el.bounds.h) / maxArea;
      const positionScore = el.inViewport ? 1 : 0.3;
      const interactiveScore = el.interactive ? 1.5 : 1;
      const semanticScore = ['button','cta','link','navigation'].includes(el.semantic) ? 1.3 : 1;
      
      el.attentionWeight = Math.min(1, sizeScore * 0.3 + positionScore * 0.2 + interactiveScore * 0.3 + semanticScore * 0.2);
    });
    
    // 排序
    return [...elements].sort((a, b) => b.attentionWeight - a.attentionWeight);
  }

  /**
   * 生成自然语言布局描述
   */
  function generateLayoutDescription(elements, semanticIndex) {
    const { byRole, byRegion } = semanticIndex;
    const parts = [];
    
    const total = elements.length;
    const interactive = elements.filter(e => e.interactive).length;
    const inViewport = elements.filter(e => e.inViewport).length;
    
    parts.push(`页面包含 ${total} 个元素，${interactive} 个可交互，${inViewport} 个在当前视口内。`);
    
    // 描述语义结构
    const roles = Object.entries(byRole).sort((a,b) => b[1].length - a[1].length);
    if (roles.length > 0) {
      parts.push(`语义类型: ${roles.map(([r, ids]) => `${r}(${ids.length})`).join(', ')}。`);
    }
    
    // 描述空间布局
    const headerEls = byRegion.header || [];
    const footerEls = byRegion.footer || [];
    const bodyEls = byRegion.body || [];
    
    if (headerEls.length > 0) parts.push(`页头区域有 ${headerEls.length} 个元素。`);
    if (bodyEls.length > 0) parts.push(`主体区域有 ${bodyEls.length} 个元素。`);
    if (footerEls.length > 0) parts.push(`页脚区域有 ${footerEls.length} 个元素。`);
    
    // 描述密度
    const viewportWidth = window.innerWidth;
    const avgWidth = elements.reduce((s, e) => s + e.bounds.w, 0) / Math.max(total, 1);
    if (avgWidth > viewportWidth * 0.6) parts.push(`元素多为全宽布局。`);
    else if (avgWidth < viewportWidth * 0.3) parts.push(`元素多为窄列布局。`);
    
    return parts.join(' ');
  }

  global.AgentRuntime.semantics = { buildSemanticIndex, calculateAttentionWeights, generateLayoutDescription };
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  /**
   * 计算单个元素的可见性
   */
  function computeVisibility(el) {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    
    const display = style.display;
    const visibility = style.visibility;
    const opacity = parseFloat(style.opacity || 1);
    const zIndex = parseInt(style.zIndex || 0);
    
    const isVisible = display !== 'none' && visibility !== 'hidden' && opacity > 0 && rect.width > 0 && rect.height > 0;
    const inViewport = rect.bottom > 0 && rect.top < window.innerHeight && rect.right > 0 && rect.left < window.innerWidth;
    
    // 视口覆盖率
    const viewportArea = window.innerWidth * window.innerHeight;
    const elArea = rect.width * rect.height;
    const visibleArea = Math.max(0, Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0)) *
                        Math.max(0, Math.min(rect.right, window.innerWidth) - Math.max(rect.left, 0));
    const viewportCoverage = viewportArea > 0 ? visibleArea / viewportArea : 0;
    
    return {
      visible: isVisible,
      inViewport,
      opacity,
      zIndex,
      viewportCoverage: Math.round(viewportCoverage * 10000) / 10000,
      scrollPosition: {
        fromTop: Math.round(rect.top + window.scrollY),
        fromBottom: Math.round(document.body.scrollHeight - rect.bottom - window.scrollY)
      }
    };
  }

  /**
   * 批量更新所有元素的可见性
   */
  function updateAllVisibility(elements) {
    elements.forEach(el => {
      if (el._el) {
        const vis = computeVisibility(el._el);
        el.visible = vis.visible;
        el.inViewport = vis.inViewport;
        el.viewportCoverage = vis.viewportCoverage;
        el.opacity = vis.opacity;
        el.zIndex = vis.zIndex;
      }
    });
  }

  global.AgentRuntime.visibility = { computeVisibility, updateAllVisibility };
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  class SpatialQuery {
    constructor(world) {
      this.world = world;
    }

    /** 按语义角色查找 */
    findByRole(role) {
      return (this.world.semanticIndex?.byRole?.[role] || []);
    }

    /** 按标签查找 */
    findByTag(tag) {
      return [...this.world.elements.values()]
        .filter(e => e.tag === tag.toLowerCase())
        .map(e => e.id);
    }

    /** 所有可交互元素 */
    findInteractive() {
      return [...this.world.elements.values()]
        .filter(e => e.interactive)
        .map(e => e.id);
    }

    /** 在视口内的元素 */
    findInViewport() {
      return [...this.world.elements.values()]
        .filter(e => e.inViewport)
        .map(e => e.id);
    }

    /** 获取元素详情 */
    getElement(id) {
      const el = this.world.elements.get(id);
      if (!el) return null;
      // 不暴露 _el 引用
      const { _el, ...safe } = el;
      return safe;
    }

    /** 查找邻近元素 */
    nearby(id, radius = 3) {
      const target = this.world.elements.get(id);
      if (!target) return [];
      return [...this.world.elements.values()]
        .filter(el => {
          if (el.id === id) return false;
          const dist = global.AgentRuntime.topology.elementDistance(target, el);
          return dist < radius;
        })
        .map(el => el.id);
    }

    /** 获取元素的邻居 */
    getNeighbors(id) {
      return this.world.topology?.adjacency?.get(id) || { top: [], bottom: [], left: [], right: [] };
    }

    /** 查找空白区域 */
    findEmptyRegions(minGridCells = 10) {
      const grid = this.world.occupancy;
      if (!grid || !grid.grid) return [];
      
      const visited = new Set();
      const regions = [];
      
      for (let y = 0; y < grid.rows; y++) {
        for (let x = 0; x < grid.cols; x++) {
          const key = `${x},${y}`;
          if (visited.has(key)) continue;
          if (grid.grid[y]?.[x]?.occupied) continue;
          
          // BFS 找连通空白区域
          const region = bfsEmpty(grid, x, y, visited);
          if (region.cells >= minGridCells) {
            regions.push({
              id: `region-${regions.length}`,
              bounds: region.bounds,
              cells: region.cells,
              areaPx: region.cells * grid.cellSize * grid.cellSize,
              center: {
                gx: Math.round((region.bounds.gx1 + region.bounds.gx2) / 2),
                gy: Math.round((region.bounds.gy1 + region.bounds.gy2) / 2)
              }
            });
          }
        }
      }
      
      return regions.sort((a, b) => b.cells - a.cells);
    }

    /** 导航路径 */
    navigationPath() {
      return this.world.topology?.navigationPath || [];
    }

    /** 自然语言描述 */
    describe() {
      const elements = [...this.world.elements.values()];
      return global.AgentRuntime.semantics.generateLayoutDescription(
        elements,
        this.world.semanticIndex
      );
    }

    /** 页面摘要 */
    getPageSummary() {
      const elements = [...this.world.elements.values()];
      const interactive = elements.filter(e => e.interactive);
      const inViewport = elements.filter(e => e.inViewport);
      const emptyRegions = this.findEmptyRegions();
      
      return {
        total: elements.length,
        interactive: interactive.length,
        inViewport: inViewport.length,
        emptyRegions: emptyRegions.length,
        viewport: { width: window.innerWidth, height: window.innerHeight },
        scroll: { y: window.scrollY, totalHeight: document.body.scrollHeight },
        semanticTypes: Object.keys(this.world.semanticIndex?.byRole || {}).length
      };
    }

    /** 完整快照 */
    getSnapshot() {
      const elements = [...this.world.elements.values()].map(e => {
        const { _el, ...safe } = e;
        return safe;
      });
      return {
        version: this.world.version,
        meta: this.world.meta,
        elements,
        summary: this.getPageSummary(),
        emptyRegions: this.findEmptyRegions(),
        navigationPath: this.navigationPath()
      };
    }
  }

  function bfsEmpty(grid, startX, startY, visited) {
    const queue = [{ x: startX, y: startY }];
    visited.add(`${startX},${startY}`);
    let cells = 0;
    let gx1 = startX, gy1 = startY, gx2 = startX, gy2 = startY;
    
    while (queue.length > 0) {
      const { x, y } = queue.shift();
      cells++;
      gx1 = Math.min(gx1, x); gy1 = Math.min(gy1, y);
      gx2 = Math.max(gx2, x); gy2 = Math.max(gy2, y);
      
      const neighbors = [{ x: x-1, y }, { x: x+1, y }, { x, y: y-1 }, { x, y: y+1 }];
      for (const n of neighbors) {
        const key = `${n.x},${n.y}`;
        if (visited.has(key)) continue;
        if (n.x < 0 || n.x >= grid.cols || n.y < 0 || n.y >= grid.rows) continue;
        if (grid.grid[n.y]?.[n.x]?.occupied) continue;
        visited.add(key);
        queue.push(n);
      }
    }
    
    return { cells, bounds: { gx1, gy1, gx2, gy2 } };
  }

  global.AgentRuntime.SpatialQuery = SpatialQuery;
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  let observer = null;
  let debounceTimer = null;
  const DEBOUNCE_MS = 150;

  /**
   * 启动 DOM 变化观察
   */
  function startDOMObserver(onChange) {
    if (observer) observer.disconnect();
    
    observer = new MutationObserver((mutations) => {
      // 过滤有意义的变更
      const relevant = mutations.filter(m => {
        if (m.type === 'childList') return true;
        if (m.type === 'attributes') {
          const attr = m.attributeName;
          return ['style', 'class', 'id', 'role', 'aria-label', 'hidden', 'disabled'].includes(attr);
        }
        return false;
      });
      
      if (relevant.length === 0) return;
      
      // 防抖
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        onChange(relevant);
      }, DEBOUNCE_MS);
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class', 'id', 'role', 'aria-label', 'hidden', 'disabled']
    });
    
    // 监听滚动（更新可见性）
    let scrollTimer = null;
    window.addEventListener('scroll', () => {
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(() => {
        onChange([{ type: 'scroll' }]);
      }, 100);
    }, { passive: true });
    
    // 监听 resize
    let resizeTimer = null;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        onChange([{ type: 'resize' }]);
      }, 200);
    }, { passive: true });
    
    return observer;
  }

  function stopDOMObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  global.AgentRuntime.observer = { startDOMObserver, stopDOMObserver };
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  class AgentRuntime {
    constructor() {
      this.world = {
        version: '1.0.0',
        elements: new Map(),
        occupancy: null,
        topology: null,
        semanticIndex: null,
        meta: null,
        query: null
      };
      this.occupancyGrid = null;
      this.spatialQuery = null;
      this.updateCount = 0;
    }

    /**
     * 初始化：全量扫描 + 启动监听
     */
    init() {
      const startTime = performance.now();
      
      // 1. 全量扫描
      const elements = global.AgentRuntime.scanner.scanAll();
      elements.forEach(el => this.world.elements.set(el.id, el));
      
      // 2. 计算可见性
      global.AgentRuntime.visibility.updateAllVisibility(elements);
      
      // 3. 构建空间层
      this.rebuildSpatialLayers();
      
      // 4. 创建查询引擎
      this.spatialQuery = new global.AgentRuntime.SpatialQuery(this.world);
      this.world.query = this.spatialQuery;
      
      // 5. 记录 meta
      this.world.meta = {
        url: window.location.href,
        title: document.title,
        initializedAt: Date.now(),
        initTime: Math.round(performance.now() - startTime),
        elementCount: this.world.elements.size
      };
      
      console.log(`[Agent Runtime] Initialized: ${this.world.elements.size} elements in ${this.world.meta.initTime}ms`);
      
      // 6. 启动 DOM 观察
      global.AgentRuntime.observer.startDOMObserver((mutations) => {
        this.handleMutation(mutations);
      });
    }

    /**
     * 处理 DOM 变化 — 增量更新
     */
    handleMutation(mutations) {
      this.updateCount++;
      const changedIds = new Set();
      
      mutations.forEach(m => {
        if (m.type === 'scroll' || m.type === 'resize') {
          // 滚动/resize 只需更新可见性
          return;
        }
        
        // 处理新增节点
        if (m.addedNodes) {
          m.addedNodes.forEach(node => {
            if (node.nodeType !== Node.ELEMENT_NODE) return;
            const el = global.AgentRuntime.scanner.scanElement(node);
            if (el) {
              this.world.elements.set(el.id, el);
              changedIds.add(el.id);
            }
            // 子节点也扫描
            if (node.querySelectorAll) {
              node.querySelectorAll('*').forEach(child => {
                const cel = global.AgentRuntime.scanner.scanElement(child);
                if (cel) {
                  this.world.elements.set(cel.id, cel);
                  changedIds.add(cel.id);
                }
              });
            }
          });
        }
        
        // 处理属性变化
        if (m.type === 'attributes' && m.target.nodeType === Node.ELEMENT_NODE) {
          const el = global.AgentRuntime.scanner.scanElement(m.target);
          if (el) {
            this.world.elements.set(el.id, el);
            changedIds.add(el.id);
          }
        }
        
        // 处理删除节点
        if (m.removedNodes) {
          m.removedNodes.forEach(node => {
            if (node.nodeType !== Node.ELEMENT_NODE) return;
            const id = global.AgentRuntime.scanner.getStableId(node);
            this.world.elements.delete(id);
            changedIds.add(id);
            if (node.querySelectorAll) {
              node.querySelectorAll('*').forEach(child => {
                const cid = global.AgentRuntime.scanner.getStableId(child);
                this.world.elements.delete(cid);
                changedIds.add(cid);
              });
            }
          });
        }
      });
      
      // 更新可见性
      const allElements = [...this.world.elements.values()];
      global.AgentRuntime.visibility.updateAllVisibility(allElements);
      
      // 增量更新占位网格
      if (changedIds.size > 0 && this.occupancyGrid) {
        const changed = allElements.filter(e => changedIds.has(e.id));
        this.occupancyGrid.incrementalUpdate(changed);
      }
      
      // 如果变化较大，重建拓扑和语义
      if (changedIds.size > 5 || mutations.some(m => m.type === 'childList')) {
        this.rebuildSpatialLayers();
      }
      
      // 更新 meta
      this.world.meta.elementCount = this.world.elements.size;
      this.world.meta.lastUpdate = Date.now();
      this.world.meta.updateCount = this.updateCount;
    }

    /**
     * 重建空间层（拓扑 + 语义）
     */
    rebuildSpatialLayers() {
      const elements = [...this.world.elements.values()];
      
      // 占位网格
      if (!this.occupancyGrid) {
        this.occupancyGrid = new global.AgentRuntime.OccupancyGrid();
      }
      this.occupancyGrid.rebuild(elements);
      this.world.occupancy = this.occupancyGrid;
      
      // 拓扑
      this.world.topology = global.AgentRuntime.topology.buildTopology(elements);
      
      // 语义索引
      this.world.semanticIndex = global.AgentRuntime.semantics.buildSemanticIndex(elements);
      global.AgentRuntime.semantics.calculateAttentionWeights(elements);
    }

    /**
     * 强制全量刷新
     */
    forceRefresh() {
      this.world.elements.clear();
      this.init();
    }
  }

  global.AgentRuntime.AgentRuntime = AgentRuntime;
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  let currentMode = 'off';
  let overlayContainer = null;

  function createContainer() {
    if (overlayContainer) return overlayContainer;
    overlayContainer = document.createElement('div');
    overlayContainer.id = 'agent-runtime-overlay';
    overlayContainer.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:999999;';
    document.body.appendChild(overlayContainer);
    return overlayContainer;
  }

  function clearOverlay() {
    const container = document.getElementById('agent-runtime-overlay');
    if (container) container.innerHTML = '';
  }

  function toggleOverlay(mode, world) {
    clearOverlay();
    currentMode = mode;
    
    if (mode === 'off') return;
    
    const container = createContainer();
    const elements = [...world.elements.values()];
    
    switch(mode) {
      case 'grid': drawGrid(container); break;
      case 'elements': drawElements(container, elements); break;
      case 'regions': drawRegions(container, world); break;
      case 'all':
        drawGrid(container);
        drawElements(container, elements);
        drawRegions(container, world);
        break;
    }
  }

  function drawGrid(container) {
    const GRID = 40;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;';
    svg.setAttribute('width', window.innerWidth);
    svg.setAttribute('height', document.body.scrollHeight);
    
    for (let x = 0; x <= window.innerWidth; x += GRID) {
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', x); line.setAttribute('y1', 0);
      line.setAttribute('x2', x); line.setAttribute('y2', document.body.scrollHeight);
      line.setAttribute('stroke', 'rgba(125,211,252,0.1)'); line.setAttribute('stroke-width', '1');
      svg.appendChild(line);
    }
    for (let y = 0; y <= document.body.scrollHeight; y += GRID) {
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', 0); line.setAttribute('y1', y);
      line.setAttribute('x2', window.innerWidth); line.setAttribute('y2', y);
      line.setAttribute('stroke', 'rgba(125,211,252,0.1)'); line.setAttribute('stroke-width', '1');
      svg.appendChild(line);
    }
    container.appendChild(svg);
  }

  function drawElements(container, elements) {
    const colorMap = {
      navigation: '#7dd3fc', button: '#86efac', link: '#86efac',
      input: '#fbbf24', heading: '#c084fc', banner: '#7dd3fc',
      contentinfo: '#f87171', dialog: '#fb923c', card: '#a78bfa',
      content: '#64748b', img: '#f472b6'
    };
    
    elements.forEach(el => {
      if (!el.inViewport) return;
      const div = document.createElement('div');
      const color = colorMap[el.semantic] || '#64748b';
      div.style.cssText = `position:absolute;left:${el.bounds.x}px;top:${el.bounds.y}px;width:${el.bounds.w}px;height:${el.bounds.h}px;border:1px solid ${color};border-radius:2px;pointer-events:none;`;
      
      // 标签
      const label = document.createElement('span');
      label.style.cssText = `position:absolute;top:-14px;left:0;font-size:9px;font-family:monospace;color:${color};background:rgba(0,0,0,0.7);padding:1px 4px;border-radius:2px;white-space:nowrap;`;
      label.textContent = el.semantic;
      div.appendChild(label);
      
      container.appendChild(div);
    });
  }

  function drawRegions(container, world) {
    if (!world.query) return;
    const regions = world.query.findEmptyRegions(10);
    
    regions.forEach(region => {
      const GRID = 40;
      const div = document.createElement('div');
      div.style.cssText = `position:absolute;left:${region.bounds.gx1*GRID}px;top:${region.bounds.gy1*GRID}px;width:${(region.bounds.gx2-region.bounds.gx1+1)*GRID}px;height:${(region.bounds.gy2-region.bounds.gy1+1)*GRID}px;border:2px dashed rgba(251,191,36,0.4);background:rgba(251,191,36,0.05);border-radius:4px;pointer-events:none;`;
      
      const label = document.createElement('span');
      label.style.cssText = 'position:absolute;top:4px;left:4px;font-size:10px;font-family:monospace;color:#fbbf24;opacity:0.7;';
      label.textContent = `${region.cells}格`;
      div.appendChild(label);
      
      container.appendChild(div);
    });
  }

  global.AgentRuntime.overlay = { toggleOverlay, clearOverlay };
})(window);
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  /**
   * 挂载 window.agentWorld — Agent 的统一入口
   */
  function mountAgentWorld(runtime) {
    const query = runtime.world.query;
    
    global.agentWorld = {
      version: '1.0.0',
      
      // 页面元信息
      meta: runtime.world.meta,
      
      // 查询 API
      query: {
        findByRole: (role) => query.findByRole(role),
        findByTag: (tag) => query.findByTag(tag),
        findInteractive: () => query.findInteractive(),
        findInViewport: () => query.findInViewport(),
        getElement: (id) => query.getElement(id),
        nearby: (id, radius) => query.nearby(id, radius),
        getNeighbors: (id) => query.getNeighbors(id),
        findEmptyRegions: () => query.findEmptyRegions(),
        navigationPath: () => query.navigationPath(),
        describe: () => query.describe(),
        getPageSummary: () => query.getPageSummary(),
        getSnapshot: () => query.getSnapshot()
      },
      
      // 可视化
      toggleOverlay: (mode) => global.AgentRuntime.overlay.toggleOverlay(mode, runtime.world),
      
      // 刷新
      refresh: () => runtime.forceRefresh(),
      
      // 内部状态
      _runtime: runtime
    };
    
    console.log('[Agent Runtime] window.agentWorld ready');
  }

  global.AgentRuntime.mountAgentWorld = mountAgentWorld;
})(window);
(function() {
  'use strict';
  
  // 等待 DOM 就绪
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }
  
  function bootstrap() {
    try {
      const runtime = new window.AgentRuntime.AgentRuntime();
      runtime.init();
      window.AgentRuntime.mountAgentWorld(runtime);
      
      console.log('[Agent Runtime] ✅ World ready — try window.agentWorld.query.describe()');
    } catch(e) {
      console.error('[Agent Runtime] ❌ Bootstrap failed:', e);
    }
  }
})();
