// 全局命名空间
window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  const GRID_SIZE = 40;
  let idCounter = 0;
  const idMap = new WeakMap(); // 稳定ID映射

  /**
   * 为元素生成稳定ID
   */
  function getStableId(el) {
    if (idMap.has(el)) return idMap.get(el);
    if (el.id) {
      idMap.set(el, el.id);
      return el.id;
    }
    const id = `el_${el.tagName.toLowerCase()}_${++idCounter}`;
    idMap.set(el, id);
    return id;
  }

  /**
   * 扫描单个元素（不是整个页面）
   */
  function scanElement(el) {
    if (!el || !el.getBoundingClientRect) return null;
    
    const rect = el.getBoundingClientRect();
    
    // 过滤太小/不可见的元素
    if (rect.width < 3 || rect.height < 3) return null;
    
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) return null;
    
    // 过滤纯装饰/无意义元素
    const tag = el.tagName.toLowerCase();
    const skipTags = new Set(['br','hr','script','style','link','meta','noscript','svg','path','g','defs','use']);
    if (skipTags.has(tag)) return null;
    
    const id = getStableId(el);
    
    return {
      id,
      tag,
      text: (el.textContent || '').trim().substring(0, 100),
      bounds: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        w: Math.round(rect.width),
        h: Math.round(rect.height)
      },
      grid: {
        gx: Math.floor(rect.x / GRID_SIZE),
        gy: Math.floor(rect.y / GRID_SIZE),
        gw: Math.ceil(rect.width / GRID_SIZE),
        gh: Math.ceil(rect.height / GRID_SIZE)
      },
      interactive: isInteractive(el, tag, style),
      semantic: inferSemanticRole(el, tag),
      attributes: {
        role: el.getAttribute('role'),
        ariaLabel: el.getAttribute('aria-label'),
        className: el.className || '',
        href: el.getAttribute('href'),
        type: el.getAttribute('type'),
        placeholder: el.getAttribute('placeholder')
      },
      depth: getDepth(el),
      _el: el // 保留 DOM 引用（内部使用，不暴露给 Agent）
    };
  }

  function isInteractive(el, tag, style) {
    const interactiveTags = new Set(['a','button','input','select','textarea','option','details','summary']);
    if (interactiveTags.has(tag)) return true;
    if (el.getAttribute('onclick') || el.getAttribute('tabindex')) return true;
    if (style.cursor === 'pointer') return true;
    if (el.getAttribute('role') === 'button') return true;
    return false;
  }

  function inferSemanticRole(el, tag) {
    // 1. ARIA role
    const ariaRole = el.getAttribute('role');
    if (ariaRole) return ariaRole;
    
    // 2. 语义化标签
    const tagRoles = {
      nav: 'navigation', header: 'banner', footer: 'contentinfo',
      main: 'main', aside: 'complementary', article: 'article',
      section: 'region', form: 'form', button: 'button',
      a: 'link', input: 'input', select: 'listbox',
      textarea: 'textbox', h1: 'heading', h2: 'heading',
      h3: 'heading', h4: 'heading', h5: 'heading', h6: 'heading',
      img: 'img', video: 'video', audio: 'audio',
      table: 'table', ul: 'list', ol: 'list', li: 'listitem',
      dialog: 'dialog', menu: 'menu'
    };
    if (tagRoles[tag]) return tagRoles[tag];
    
    // 3. class/id 启发式
    const cls = (el.className || '').toLowerCase() + ' ' + (el.id || '').toLowerCase();
    const heuristics = [
      [/nav|menu/, 'navigation'], [/btn|button/, 'button'],
      [/card/, 'card'], [/hero|banner/, 'banner'],
      [/sidebar/, 'complementary'], [/modal|dialog|popup/, 'dialog'],
      [/tab/, 'tab'], [/dropdown/, 'listbox'],
      [/tooltip/, 'tooltip'], [/carousel|slider/, 'group'],
      [/cta/, 'cta'], [/footer/, 'contentinfo'],
      [/header/, 'banner']
    ];
    for (const [pattern, role] of heuristics) {
      if (pattern.test(cls)) return role;
    }
    
    return 'content';
  }

  function getDepth(el) {
    let depth = 0;
    let current = el;
    while (current.parentElement) { depth++; current = current.parentElement; }
    return depth;
  }

  // 全量扫描（初始化用）
  function scanAll() {
    const elements = [];
    document.querySelectorAll('*').forEach(el => {
      const node = scanElement(el);
      if (node) elements.push(node);
    });
    return elements;
  }

  global.AgentRuntime.scanner = { scanElement, scanAll, getStableId, GRID_SIZE };
})(window);
