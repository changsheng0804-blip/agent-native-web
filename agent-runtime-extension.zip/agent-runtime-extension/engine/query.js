window.AgentRuntime = window.AgentRuntime || {};

(function(global) {
  'use strict';

  class SpatialQuery {
    constructor(world) {
      this.world = world;
    }

    /** 按语义角色查找 */
    findByRole(role) {
      return (this.world.semanticIndex?.byRole?.[role] || []);
    }

    /** 按标签查找 */
    findByTag(tag) {
      return [...this.world.elements.values()]
        .filter(e => e.tag === tag.toLowerCase())
        .map(e => e.id);
    }

    /** 所有可交互元素 */
    findInteractive() {
      return [...this.world.elements.values()]
        .filter(e => e.interactive)
        .map(e => e.id);
    }

    /** 在视口内的元素 */
    findInViewport() {
      return [...this.world.elements.values()]
        .filter(e => e.inViewport)
        .map(e => e.id);
    }

    /** 获取元素详情 */
    getElement(id) {
      const el = this.world.elements.get(id);
      if (!el) return null;
      // 不暴露 _el 引用
      const { _el, ...safe } = el;
      return safe;
    }

    /** 查找邻近元素 */
    nearby(id, radius = 3) {
      const target = this.world.elements.get(id);
      if (!target) return [];
      return [...this.world.elements.values()]
        .filter(el => {
          if (el.id === id) return false;
          const dist = global.AgentRuntime.topology.elementDistance(target, el);
          return dist < radius;
        })
        .map(el => el.id);
    }

    /** 获取元素的邻居 */
    getNeighbors(id) {
      return this.world.topology?.adjacency?.get(id) || { top: [], bottom: [], left: [], right: [] };
    }

    /** 查找空白区域 */
    findEmptyRegions(minGridCells = 10) {
      const grid = this.world.occupancy;
      if (!grid || !grid.grid) return [];
      
      const visited = new Set();
      const regions = [];
      
      for (let y = 0; y < grid.rows; y++) {
        for (let x = 0; x < grid.cols; x++) {
          const key = `${x},${y}`;
          if (visited.has(key)) continue;
          if (grid.grid[y]?.[x]?.occupied) continue;
          
          // BFS 找连通空白区域
          const region = bfsEmpty(grid, x, y, visited);
          if (region.cells >= minGridCells) {
            regions.push({
              id: `region-${regions.length}`,
              bounds: region.bounds,
              cells: region.cells,
              areaPx: region.cells * grid.cellSize * grid.cellSize,
              center: {
                gx: Math.round((region.bounds.gx1 + region.bounds.gx2) / 2),
                gy: Math.round((region.bounds.gy1 + region.bounds.gy2) / 2)
              }
            });
          }
        }
      }
      
      return regions.sort((a, b) => b.cells - a.cells);
    }

    /** 导航路径 */
    navigationPath() {
      return this.world.topology?.navigationPath || [];
    }

    /** 自然语言描述 */
    describe() {
      const elements = [...this.world.elements.values()];
      return global.AgentRuntime.semantics.generateLayoutDescription(
        elements,
        this.world.semanticIndex
      );
    }

    /** 页面摘要 */
    getPageSummary() {
      const elements = [...this.world.elements.values()];
      const interactive = elements.filter(e => e.interactive);
      const inViewport = elements.filter(e => e.inViewport);
      const emptyRegions = this.findEmptyRegions();
      
      return {
        total: elements.length,
        interactive: interactive.length,
        inViewport: inViewport.length,
        emptyRegions: emptyRegions.length,
        viewport: { width: window.innerWidth, height: window.innerHeight },
        scroll: { y: window.scrollY, totalHeight: document.body.scrollHeight },
        semanticTypes: Object.keys(this.world.semanticIndex?.byRole || {}).length
      };
    }

    /** 完整快照 */
    getSnapshot() {
      const elements = [...this.world.elements.values()].map(e => {
        const { _el, ...safe } = e;
        return safe;
      });
      return {
        version: this.world.version,
        meta: this.world.meta,
        elements,
        summary: this.getPageSummary(),
        emptyRegions: this.findEmptyRegions(),
        navigationPath: this.navigationPath()
      };
    }
  }

  function bfsEmpty(grid, startX, startY, visited) {
    const queue = [{ x: startX, y: startY }];
    visited.add(`${startX},${startY}`);
    let cells = 0;
    let gx1 = startX, gy1 = startY, gx2 = startX, gy2 = startY;
    
    while (queue.length > 0) {
      const { x, y } = queue.shift();
      cells++;
      gx1 = Math.min(gx1, x); gy1 = Math.min(gy1, y);
      gx2 = Math.max(gx2, x); gy2 = Math.max(gy2, y);
      
      const neighbors = [{ x: x-1, y }, { x: x+1, y }, { x, y: y-1 }, { x, y: y+1 }];
      for (const n of neighbors) {
        const key = `${n.x},${n.y}`;
        if (visited.has(key)) continue;
        if (n.x < 0 || n.x >= grid.cols || n.y < 0 || n.y >= grid.rows) continue;
        if (grid.grid[n.y]?.[n.x]?.occupied) continue;
        visited.add(key);
        queue.push(n);
      }
    }
    
    return { cells, bounds: { gx1, gy1, gx2, gy2 } };
  }

  global.AgentRuntime.SpatialQuery = SpatialQuery;
})(window);
